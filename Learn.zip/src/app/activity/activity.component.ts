import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-activity',
  templateUrl: './activity.component.html',
  styleUrls: ['./activity.component.css']
})
export class ActivityComponent implements OnInit {
parts1:any;
  constructor(private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
    this.http.get('http://localhost:3000/parts').subscribe((result=>{
      this.parts1=result;
    }))
  }

}
