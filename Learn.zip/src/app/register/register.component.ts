import { HttpClient, JsonpInterceptor } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CrudService } from '../service/crud.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registration=new FormGroup(
    {
      full_name:new FormControl('',[Validators.required]),
      password:new FormControl('',[Validators.required]),
      email:new FormControl('',[Validators.required]),
      password2:new FormControl('',[Validators.required]),
    })

    // readData():boolean{
    //   let read=this.registration;
    //   for(let i=0;i<this.registration;i++)

    // }
  read=1;
  register(){
    if(this.registration.value.password==this.registration.value.password2){
      // let empData=JSON.parse(JSON.stringify(this.registration));
      this.http.post('http://localhost:3000/Register',this.registration.value).subscribe((result)=>{
        alert("Employee Register Successful");
        console.log('result',result);
      })
      this.registration.reset();
      this.router.navigate(['']);
    }
    else{
      console.log("Password Not Matched");
    }
      

  }
  constructor(private router:Router,private http:HttpClient) { }

  ngOnInit(): void {
    }
  

}
