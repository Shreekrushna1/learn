import { Component, Input, OnInit } from '@angular/core';
import {CrudService} from '../../service/crud.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
list:any;
  constructor(private crudService : CrudService,private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
 this.http.get('http://localhost:3000/home').subscribe((result=>{
      this.list=result;
    }))
  }
}
