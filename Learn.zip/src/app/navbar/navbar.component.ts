import { HttpBackend, HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {CrudService} from '../service/crud.service';
import {LoginComponent} from '../login/login/login.component';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  
  constructor(private crudService:CrudService,private http:HttpClient) { }
  
  ngOnInit(): void {
  }

}
