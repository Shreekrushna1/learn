import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-employee',
  templateUrl: './new-employee.component.html',
  styleUrls: ['./new-employee.component.css']
})
export class NewEmployeeComponent implements OnInit {
  newEmp=new FormGroup({
    // username:new FormControl('',[Validators.required]),
    // password:new FormControl('',[Validators.required]),
    email:new FormControl('',[Validators.email]),
    designation:new FormControl('',[Validators.required]),
  })

  

  addEmp(data:any){
    this.http.post('http://127.0.0.1:8000/Employee/',data).subscribe((result)=>{
      alert("Employee Add Successful");
      console.log('result',result);
    })
    // console.log(this.register.value);
    this.newEmp.reset();
    this.router.navigate(['/dashboard']);
    
  }


  constructor(private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
  }

}
