import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TLComponent } from './tl.component';

describe('TLComponent', () => {
  let component: TLComponent;
  let fixture: ComponentFixture<TLComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TLComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TLComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
