import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity3',
  templateUrl: './activity3.component.html',
  styleUrls: ['./activity3.component.css']
})
export class Activity3Component implements OnInit {
btn="Button";
  constructor() { }
changeText(){
      this.btn="Completed";
    }
  ngOnInit(): void {
    
  }

}
