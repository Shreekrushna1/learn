import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit {
  list=[
    {
      number:'1',
      name:'add Employee',
      icon:'fa fa-male',
      href:'/list'
  },{
    number:'2',
    name:'Go To List',
    icon:'fa fa-search'
  }

  ];

  constructor() { }

  ngOnInit(): void {
  }

}
